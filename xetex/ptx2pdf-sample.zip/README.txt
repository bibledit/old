The files here contain Michael Paul Johnson's translation of John's Gospel and Epistles, along with setup files for the ptx2pdf macro package.

The Scripture files here are copies of the USFM files available from http://eBible.org/glw/, with the following minor modifications:

(1) In the file Intro-GLW.sfm, changed markers:
    \id1 -> \id
    \it  -> \imt
    \p   -> \ip

(2) In 43-JHN-GLW.sfm, added \nb after \c at chapters 8 and 10, and reordered \p \c to the usual Paratext order \c \p.

(3) Replaced curly apostrophe ’ with straight ' in all \id lines.

usfm.sty is the USFM Paratext stylesheet, version 2.1, which defines the format markers.

GLW-setup.txt contains general setup parameters, and GLW-custom.sty contains overrides for a few things defined in the usfm stylesheet.

To format with XeTeX and the ptx2pdf macros, run xetex on the file GLW.tex to create GLW.pdf.

Note that up to 4 runs are needed for all the formatting to stabilize (chapter number 8 is the main problem case in this setup). The macros will print a message to the terminal if additional runs are needed.


Copyright information from the original archive follows:
--------------------------------------------------------------------

God's Living Word Translation is Copyright (C) 1996 Michael Paul
Johnson. All rights reserved. "God's Living Word Translation" and "GLW"
are trademarks of Michael Paul Johnson. God's Living Word Translation
may be copied or quoted in any form (printed, electronic, audio,
broadcast, etc.), up to and inclusive of the entire text, for either
commercial or noncommercial purposes, without additional express
written permission of the copyright holder and without payment of
royalties, and the GLW trademark may be used, providing that the text
is not modified in any way and that the origin of this work is not
misrepresented. Publications of this entire work for commercial
purposes must also include this entire, unmodified copyright and
permissions notice with the work. Requests for permission to quote or
publish any or all of the God's Living Word Translation not covered by
the above should be directed to Michael Paul Johnson, PO Box 275, Mesa
CO 81643-0275, USA. http://RainbowMissions.org For more information,
please see http://eBible.org/glw/.
